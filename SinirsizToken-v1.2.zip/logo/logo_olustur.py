from PIL import Image, ImageDraw, ImageFilter, ImageChops
import math
S=1024
def lerp(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(len(a)))

def background(S):
    im=Image.new('RGBA',(S,S))
    px=im.load()
    c1=(76,40,200); c2=(14,12,40)
    for y in range(S):
        for x in range(S):
            t=min(1,((x*0.4+y)/(S*1.4)))
            d=math.hypot(x-S*0.5,y-S*0.42)/(S*0.75)
            col=lerp(c1,c2,t)
            g=max(0,1-d)**2*0.55
            col=lerp(col,(150,110,255),g)
            px[x,y]=col+(255,)
    return im

def stars(dr,S,list_):
    for cx,cy,r,col in list_:
        cx,cy,r=cx*S,cy*S,r*S
        pts=[]
        for i in range(8):
            a=math.pi/4*i - math.pi/2
            rr=r if i%2==0 else r*0.28
            pts.append((cx+rr*math.cos(a),cy+rr*math.sin(a)))
        dr.polygon(pts,fill=col)

def stroke(d,pts,w,col):
    r=w/2
    for x,y in pts: d.ellipse([x-r,y-r,x+r,y+r],fill=col)

def coin_layer(S,scale=1.0):
    """transparent layer with coin + infinity + sparkles, content sized by scale"""
    L=Image.new('RGBA',(S,S),(0,0,0,0))
    c=S/2; R=S*0.36*scale
    # glow
    glow=Image.new('RGBA',(S,S),(0,0,0,0)); g=ImageDraw.Draw(glow)
    g.ellipse([c-R*1.18,c-R*1.18,c+R*1.18,c+R*1.18],fill=(255,190,40,150))
    glow=glow.filter(ImageFilter.GaussianBlur(S*0.05*scale))
    L=Image.alpha_composite(L,glow)
    dr=ImageDraw.Draw(L)
    # outer rim (dark gold) + shading coin via concentric gradient
    dr.ellipse([c-R,c-R,c+R,c+R],fill=(196,128,0,255))
    steps=60
    for i in range(steps):
        t=i/steps; r=R*0.94*(1-t*0.999)
        col=lerp((235,160,10),(255,236,150),t**0.8)
        ox=-R*0.18*t; oy=-R*0.22*t
        dr.ellipse([c+ox-r,c+oy-r,c+ox+r,c+oy+r],fill=col+(255,))
    # inner ring
    ri=R*0.80
    dr.ellipse([c-ri,c-ri,c+ri,c+ri],outline=(205,135,0,255),width=max(2,int(R*0.045)))
    # ridges on rim
    for k in range(48):
        a=2*math.pi*k/48
        x1=c+R*0.955*math.cos(a); y1=c+R*0.955*math.sin(a)
        x2=c+R*0.995*math.cos(a); y2=c+R*0.995*math.sin(a)
        dr.line([x1,y1,x2,y2],fill=(160,100,0,255),width=max(1,int(R*0.02)))
    # infinity (lemniscate)
    A=R*0.56; w=int(R*0.17)
    pts=[]
    for i in range(0,2881):
        t=2*math.pi*i/2880
        den=1+math.sin(t)**2
        pts.append((c+A*math.cos(t)/den, c+A*math.sin(t)*math.cos(t)/den*1.15))
    # shadow
    sh=Image.new('RGBA',(S,S),(0,0,0,0)); sd=ImageDraw.Draw(sh)
    stroke(sd,[(x+R*0.03,y+R*0.04) for x,y in pts],w,(120,70,0,160))
    sh=sh.filter(ImageFilter.GaussianBlur(R*0.02))
    L=Image.alpha_composite(L,sh); dr=ImageDraw.Draw(L)
    stroke(dr,pts,w,(70,28,140,255))
    stroke(dr,[(x-R*0.012,y-R*0.016) for x,y in pts],w*0.45,(120,70,225,255))
    # shine highlight arc
    hl=Image.new('RGBA',(S,S),(0,0,0,0)); hd=ImageDraw.Draw(hl)
    hd.arc([c-R*0.87,c-R*0.87,c+R*0.87,c+R*0.87],205,245,fill=(255,255,255,190),width=int(R*0.06))
    hl=hl.filter(ImageFilter.GaussianBlur(R*0.012))
    L=Image.alpha_composite(L,hl); dr=ImageDraw.Draw(L)
    stars(dr,S,[(0.5+0.36*scale*0.95,0.5-0.36*scale*0.88,0.085*scale,(255,255,255,255)),
                (0.5-0.36*scale*1.05,0.5+0.36*scale*0.80,0.05*scale,(255,226,120,255)),
                (0.5+0.36*scale*1.2,0.5-0.36*scale*0.30,0.035*scale,(255,226,120,255))])
    return L

def rounded_mask(S,rad):
    m=Image.new('L',(S,S),0); ImageDraw.Draw(m).rounded_rectangle([0,0,S-1,S-1],radius=rad,fill=255); return m
def circle_mask(S):
    m=Image.new('L',(S,S),0); ImageDraw.Draw(m).ellipse([0,0,S-1,S-1],fill=255); return m

bg=background(S)
full=Image.alpha_composite(bg,coin_layer(S,1.0))
sq=Image.new('RGBA',(S,S),(0,0,0,0)); sq.paste(full,(0,0),rounded_mask(S,int(S*0.22)))
rd=Image.new('RGBA',(S,S),(0,0,0,0)); rd.paste(full,(0,0),circle_mask(S))
sq.save('/home/claude/logo/logo_square.png'); rd.save('/home/claude/logo/logo_round.png')
bg.save('/home/claude/logo/adaptive_bg.png')
coin_layer(S,0.62).save('/home/claude/logo/adaptive_fg.png')
# transparent coin for splash
coin_layer(S,1.0).resize((360,360),Image.LANCZOS).save('/home/claude/logo/splash_coin.png')
