<p align="center"><img src="logo/logo_512.png" width="160" alt="Sınırsız Token logo"></p>

# Sınırsız Token

İstediğin kadar token "kazandığın" eğlence amaçlı bir mini uygulama. Web (tek HTML) ve Android (APK/AAB) sürümü var.

## Özellikler
- 10 saniyelik açılış ekranı (%0 → %100)
- Ad girişi, sonraki açılışlarda hatırlanır (istersen "Adı değiştir")
- **Sınırsız hane**: sayı uzunluğunda sınır yok, toplama metin üzerinden yapılır
- **Binlik ayırıcı**: `999999999999999` → `999.999.999.999.999` (yazarken de)
- **Toplam bakiye** ve **kazanç geçmişi** (tarih/saat ile, son 100 kayıt), cihazda kalıcı
- Sıfırla butonu (iki kere basınca siler)

## Dosyalar
| Yol | Açıklama |
|---|---|
| `web/index.html` | Tek dosya, tarayıcıda direkt açılır |
| `web/template.html` | Görselleri gömülmemiş kaynak (`{{COIN}}`, `{{FAV}}`) |
| `android/` | Android kaynağı (apktool formatı: WebView + `assets/index.html`) |
| `release/` | Hazır APK ve AAB (v1.2) |
| `logo/` | Logo dosyaları ve logoyu üreten Python betiği |

## Android derleme
```bash
java -jar apktool.jar b android -o unsigned.apk
java -jar uber-apk-signer.jar -a unsigned.apk --ks <anahtar.jks> --ksAlias <alias>
```

## Kurulum
`release/SinirsizToken-v1.2.apk` dosyasını telefona indir ve kur (bilinmeyen kaynaklara izin ver).

Paket: `com.emir.tokenkazan` · minSdk 21
